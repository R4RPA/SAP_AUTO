import os
import time
from datetime import datetime
from logger_master import setup_logger
logger = setup_logger('generic_functions')


# Function to push data to db
def push_data_db(engine, df, db_name, folder_path, if_exists='replace', max_retry=30):
    """Retries writing to the database if an error occurs."""
    logger.info(f'push {db_name} to database - START')
    retry_count = 0
    retry = True
    while retry and retry_count < max_retry:
        try:
            _write_to_db_and_excel(engine, df, db_name, folder_path, if_exists)
            retry = False
        except Exception as e:
            logger.error(f'Retry count: {retry_count}, Error: {str(e)}')
            retry_count += 1
            time.sleep(10)
    if retry:
        raise ValueError(f"Max retry limit exceeded: {max_retry}")
    logger.info(f'push {db_name} to database - END')


def _write_to_db_and_excel(engine, df, db_name, folder_path, if_exists):
    """Writes the dataframe to database and excel file."""
    chunk_limit = int((2100/len(df.columns))*0.9)
    df.to_sql(name=db_name, schema='dbo', index=False, con=engine, if_exists=if_exists, chunksize=chunk_limit, method='multi')
    df.to_excel(os.path.join(folder_path, f'{db_name}.xlsx'), index=False)

def cleanup_env():
    logger.debug("Cleaning up the Environment...")
    os.system("taskkill /f /im saplogon.exe")


def kill_excel():
    try:
        logger.debug("kill excel")
        os.system('taskkill /IM EXCEL.exe /T /F')
    except:
        pass


def CheckValidFileTimeStamp(path, fileName):
    try:
        FilePath = os.path.join(path, fileName)
        ToDay = datetime.now().date()
        FileDate = datetime.fromtimestamp(os.path.getmtime(FilePath)).date()
        Download_File = FileDate < ToDay
    except Exception as e:
        if 'cannot find the file specified' not in str(e):
            logger.error(f'CheckValidFileTimeStamp Error: {str(e)}')
        Download_File = True

    return Download_File